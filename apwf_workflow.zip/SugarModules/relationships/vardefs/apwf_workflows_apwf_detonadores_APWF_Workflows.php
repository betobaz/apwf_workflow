<?php
// created: 2012-03-12 15:35:54
$dictionary["APWF_Workflows"]["fields"]["apwf_wor_apwf_detonadores"] = array (
  'name' => 'apwf_wor_apwf_detonadores',
  'type' => 'link',
  'relationship' => 'apwf_workflows_apwf_detonadores',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_APWF_WORKFLOWS_APWF_DETONADORES_FROM_APWF_DETONADORES_TITLE',
);
