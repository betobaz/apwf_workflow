<?php
// created: 2012-03-09 13:59:31
$dictionary["APWF_WorkFlow"]["fields"]["apwf_ap_w_apwf_ap_trigger"] = array (
  'name' => 'apwf_ap_w_apwf_ap_trigger',
  'type' => 'link',
  'relationship' => 'apwf_ap_workflow_apwf_ap_trigger',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_APWF_AP_WORKFLOW_APWF_AP_TRIGGER_FROM_APWF_AP_TRIGGER_TITLE',
);
