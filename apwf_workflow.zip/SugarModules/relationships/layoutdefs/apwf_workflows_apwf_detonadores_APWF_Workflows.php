<?php
// created: 2012-03-10 12:06:33
$layout_defs["APWF_Workflows"]["subpanel_setup"]["apwf_wor_apwf_detonadores"] = array (
  'order' => 100,
  'module' => 'APWF_Detonadores',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_APWF_WORKFLOWS_APWF_DETONADORES_FROM_APWF_DETONADORES_TITLE',
  'get_subpanel_data' => 'apwf_wor_apwf_detonadores',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-03-12 14:43:05
$layout_defs["APWF_Workflows"]["subpanel_setup"]["apwf_wor_apwf_detonadores"] = array (
  'order' => 100,
  'module' => 'APWF_Detonadores',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_APWF_WORKFLOWS_APWF_DETONADORES_FROM_APWF_DETONADORES_TITLE',
  'get_subpanel_data' => 'apwf_wor_apwf_detonadores',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-03-12 15:33:35
$layout_defs["APWF_Workflows"]["subpanel_setup"]["apwf_wor_apwf_detonadores"] = array (
  'order' => 100,
  'module' => 'APWF_Detonadores',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_APWF_WORKFLOWS_APWF_DETONADORES_FROM_APWF_DETONADORES_TITLE',
  'get_subpanel_data' => 'apwf_wor_apwf_detonadores',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-03-12 15:35:53
$layout_defs["APWF_Workflows"]["subpanel_setup"]["apwf_wor_apwf_detonadores"] = array (
  'order' => 100,
  'module' => 'APWF_Detonadores',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_APWF_WORKFLOWS_APWF_DETONADORES_FROM_APWF_DETONADORES_TITLE',
  'get_subpanel_data' => 'apwf_wor_apwf_detonadores',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-03-12 15:35:54
$layout_defs["APWF_Workflows"]["subpanel_setup"]["apwf_wor_apwf_detonadores"] = array (
  'order' => 100,
  'module' => 'APWF_Detonadores',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_APWF_WORKFLOWS_APWF_DETONADORES_FROM_APWF_DETONADORES_TITLE',
  'get_subpanel_data' => 'apwf_wor_apwf_detonadores',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
