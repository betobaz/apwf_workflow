<?php
// created: 2012-03-09 13:37:08
$layout_defs["APWF_WorkFlow"]["subpanel_setup"]["apwf_ap_w_apwf_ap_trigger"] = array (
  'order' => 100,
  'module' => 'APWF_AP_Trigger',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_APWF_AP_WORKFLOW_APWF_AP_TRIGGER_FROM_APWF_AP_TRIGGER_TITLE',
  'get_subpanel_data' => 'apwf_ap_w_apwf_ap_trigger',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-03-09 13:55:56
$layout_defs["APWF_WorkFlow"]["subpanel_setup"]["apwf_ap_w_apwf_ap_trigger"] = array (
  'order' => 100,
  'module' => 'APWF_AP_Trigger',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_APWF_AP_WORKFLOW_APWF_AP_TRIGGER_FROM_APWF_AP_TRIGGER_TITLE',
  'get_subpanel_data' => 'apwf_ap_w_apwf_ap_trigger',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-03-09 13:57:52
$layout_defs["APWF_WorkFlow"]["subpanel_setup"]["apwf_ap_w_apwf_ap_trigger"] = array (
  'order' => 100,
  'module' => 'APWF_AP_Trigger',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_APWF_AP_WORKFLOW_APWF_AP_TRIGGER_FROM_APWF_AP_TRIGGER_TITLE',
  'get_subpanel_data' => 'apwf_ap_w_apwf_ap_trigger',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-03-09 13:59:31
$layout_defs["APWF_WorkFlow"]["subpanel_setup"]["apwf_ap_w_apwf_ap_trigger"] = array (
  'order' => 100,
  'module' => 'APWF_AP_Trigger',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_APWF_AP_WORKFLOW_APWF_AP_TRIGGER_FROM_APWF_AP_TRIGGER_TITLE',
  'get_subpanel_data' => 'apwf_ap_w_apwf_ap_trigger',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
