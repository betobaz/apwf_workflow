<?PHP
/*********************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2011 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/

/**
 * THIS CLASS IS FOR DEVELOPERS TO MAKE CUSTOMIZATIONS IN
 */
require_once('modules/APWF_Workflows/APWF_Workflows_sugar.php');
class APWF_Workflows extends APWF_Workflows_sugar {

	private $patronVariablesTemplate = '/(\{::)(future|pass)(::)(\w+)(::)(\w+)((::)(\w+))?(::\})/';

	function APWF_Workflows(){	
		parent::APWF_Workflows_sugar();
		$this->emailAddress = new SugarEmailAddress();
	}

	public function retrieve($id = -1, $encode=true){
		$ret_val = parent::retrieve($id, $encode);
		$this->emailAddress->handleLegacyRetrieve($this);
		return $ret_val;
	}
	
	function save($check_notify = false){

		parent::save($check_notify);
		$GLOBALS['log']->debug("APWF_WorkFlow process detonadores: " . print_r($_POST, true));
		$this->load_relationships('apwf_wor_apwf_detonadores');
		$GLOBALS['log']->debug("APWF_WorkFlow save load_relationships: " . print_r($this, true));
		$detonadores = array();
		$countDetonadores = count($_POST['field_trigger']);
		for($nItem = 0; $nItem < $countDetonadores; $nItem++){
			$detonadores[] = array(
				'field_trigger' => $_POST['field_trigger'][$nItem],
				'comparacion' => $_POST['comparacion'][$nItem],
				'value_trigger' => $_POST['value_trigger'][$nItem], 
			);
		}

		$emailAddresses = array();
		$countEmailAddresses = count($_POST['email_address']);
		for($nItem = 0; $nItem < $countEmailAddresses; $nItem++){
			$emailAddresses[] = $_POST['email_address'][$nItem];
		}

		$this->saveDetonadores($detonadores);
		$this->saveEmailAddresses();

		return $this->id;
	}

	function getDetonadores(){
		$detonadores = array();
		$detonador = null;
		$db = DBManagerFactory::getInstance();
		$resultDetonadores = $db->query("SELECT ad.id FROM apwf_detonadores ad 
			INNER JOIN apwf_worpwf_detonadores_c awdc ON ad.id = awdc.apwf_wo7470ores_idb
			WHERE awdc.apwf_woad78lows_ida = '{$this->id}' 
			AND awdc.deleted = 0");

		while($row = $db->fetchByAssoc($resultDetonadores)){
			$detonador = new APWF_Detonadores();
			$detonador->retrieve($row['id']);
			if(!empty($detonador->id)){
				$this->detonadores[] = $detonador;
			}			
		}
		return $this->detonadores;
	}

	/**
	 * Funcion que procesa el workflow
	 * @param $bean <SugarBean>
	 * @return boolean
	 */
	public function process($bean){

		$GLOBALS['log']->debug("APWF_WorkFlow process this: " . print_r($this, true));			
		$this->getDetonadores();
		$this->completeDataBean($bean);		
		if(count($this->detonadores)){
			$GLOBALS['log']->debug("APWF_WorkFlow process detonadores: " . print_r($this->detonadores, true));			
			foreach($this->detonadores as $detonador){
				if(!$detonador->isValid($bean)) return false;
			}
			$GLOBALS['log']->debug("APWF_WorkFlow process action_workflow: " . $this->action_workflow);			
			switch($this->action_workflow){
				case 'send_email':
					if($this->id_email_template){
						$GLOBALS['log']->debug("APWF_WorkFlow process send email:");
						$this->sendEmail($bean);						
					}
					break;
				//default: 
			}

			return true;
		}
		return false;
	}

	/**
	 * Realiza el envio de la notificaci�n hacia las direcciones 
	 * 	de correo que se encuentren relacionadas al flujo
	 * @return void
	 */
	public function sendEmail($bean){
		$emailAddresses = $this->emailAddress->addresses;
		$GLOBALS['log']->debug("APWF_WorkFlow sendEmail emailAddresses: " . print_r($emailAddresses, true));			
		if(count($emailAddresses)){
			//Busqueda del email template
			include("modules/EmailTemplates/EmailTemplate.php");
			$emailTemp = new EmailTemplate();
			$emailTemp->disable_row_level_security = true;
			//TODO crear el campo id_email_template
			$emailTemp->retrieve($this->id_email_template);
			//$GLOBALS['log']->debug("APWF_WorkFlow sendEmail emailTemp: " . print_r($emailTemp, true));	
						
			require_once("include/SugarPHPMailer.php");
			$mail = new SugarPHPMailer();

			require_once("modules/Emails/Email.php");
			$emailObj = new Email();
			$defaults = $emailObj->getSystemDefaultEmail();

			$mail->From = $defaults['email'];
			$mail->FromName = $defaults['name'];
			$mail->Subject = $this->renderTextWithBean($bean, from_html($emailTemp->subject));
			$mail->Body = $this->renderTextWithBean($bean, from_html($emailTemp->body_html, 900));
			$mail->IsHtml(true);
			//$mail->prepForOutboud();
			$mail->setMailerForSystem();

			$GLOBALS['log']->debug("APWF_WorkFlow sendEmail mail: " . print_r($mail, true));



			foreach($emailAddresses as $emailAddress){
				$mail->ClearAllRecipients();
				//$mail->ClearReplayTos();
			  $GLOBALS['log']->debug('APWF_WorkFlow sendEmail enviando correo a: ' . print_r($emailAddress, true));
				$mail->AddAddress($emailAddress['email_address'], $emailAddress['email_address']);
				if( !$mail->Send() ){
					$GLOBALS['log']->fatal('ERROR[APWF_WorkFlow]: Message Send Failed');
				}
			}
		}
	}

	public function updateEntry(){

	}

	public function createEntry(){

	}
	/**
	 * Funcion que obtiene las direcciones de correo a la que van a ser enviadas las notificaciones
	 * @return array Arreglo con las direcciones de email
	 */
	public function getEmailAddresses(){
		$emailAddresses = array();		
		$this->load_relationships('email_addresses');
		$emailAddresses = $this->email_address->getBeans(new EmailAddress());		
		return $emailsAddress;
	}
	
	/**
	 * Funcion que guarda los detonadores
	 * @param array $detonadores 
	 */
	private function saveDetonadores($detonadores){
		$GLOBALS['log']->debug("APWF_WorkFlow saveDetonadores detonadores: " . print_r($detonadores, true));			
		if($this->fetched_row) $this->deleteRelationshipDetonadores();
		$this->load_relationships('apwf_wor_apwf_detonadores');
		foreach($detonadores as $detonadorData){
			$GLOBALS['log']->debug("APWF_WorkFlow saveDetonadores detonadorData: " . print_r($detonadorData, true));			
			$detonador = new APWF_Detonadores();	
			$detonador->field_trigger = $detonadorData['field_trigger'];
			$detonador->comparacion = $detonadorData['comparacion'];
			$detonador->value_trigger = $detonadorData['value_trigger'];
			$detonador->apwf_workflows_id_c = $detonadorData['value_trigger'];
			$detonador->save();
			//Relacionar detonador con flujo			
			$this->apwf_wor_apwf_detonadores->add($this->id);
		}
	}

	/**
	 * Funcion que guarda y relaciona las direcciones de correo
	 * @param array $emailAddresses
	 */
	private function saveEmailAddresses(){
		$this->emailAddress->handleLegacySave($this, $this->module_dir);
		$this->emailAddress->save($this->id, $this->module_dir);
	}

	/**
	 * function que elimina las relaciones existentes con los detonadores
	 */
	private function deleteRelationshipDetonadores(){
		$this->load_relationships('apwf_wor_apwf_detonadores');
		$detonadores = $this->apwf_wor_apwf_detonadores->getBeans(new APWF_Detonadores());	
		//$GLOBALS['log']->debug("APWF_WorkFlow deleteRelationshipDetonadores detonadores: " . print_r($detonadores, true));			

		foreach($detonadores as $detonador){
			$this->apwf_wor_apwf_detonadores->delete($this->id);
		}
	}

	private function renderTextWithBean($bean, $text){
		
		//$GLOBALS['log']->debug("APWF_WorkFlow renderTextWithBean bean->wfPreData: " . print_r($bean->wfPreData, true));			
		$GLOBALS['log']->debug("APWF_WorkFlow renderTextWithBean bean: " . print_r($bean, true));			

		$coincidencias = null;
		preg_match_all($this->patronVariablesTemplate, $text, $coincidencias,PREG_SET_ORDER);
		$sustituciones = array();
		$GLOBALS['log']->debug("APWF_WorkFlow renderTextWithBean text: " . $text);
		$GLOBALS['log']->debug("APWF_WorkFlow renderTextWithBean coincidencias: " . print_r($coincidencias,true));
		foreach($coincidencias as $coincidencia){

			if($coincidencia[4] === $bean->module_dir){
				$value = null;
				if( !empty($coincidencia[7]) ){
					$relationship = $coincidencia[6];
					$field_name = $coincidencia[9];

					$GLOBALS['log']->debug("APWF_WorkFlow renderTextWithBean relationship: " . $relationship);
					$GLOBALS['log']->debug("APWF_WorkFlow renderTextWithBean field_name: " . $field_name);

					if(!$bean->$relationship){
						$bean->load_relationships($relationship);
					}

					$beansRelationship = $bean->$relationship->getBeans(new SugarBean());
					if(count($beansRelationship)){
						$value = $beansRelationship[0]->$field_name;
					}

				}else{
					if($coincidencia[2] === 'future'){
						$field_name = $coincidencia[6];
						$value = $bean->$field_name;
						$GLOBALS['log']->debug("APWF_WorkFlow renderTextWithBean field_name: " . $field_name);
						$GLOBALS['log']->debug("APWF_WorkFlow renderTextWithBean bean->field_name: " . $bean->$field_name);
					}else{
						$value = $bean->wfPreData[$coincidencia[6]];
					}
				}
				$sustituciones[$coincidencia[0]] = $value;
			}
			
		}

		return str_replace(array_keys($sustituciones), array_values($sustituciones), $text);
	}
	
	private function completeDataBean($bean){
		global  $beanList, $beanFiles;
  	$class_name = $beanList[$bean->module_dir];
		require_once($beanFiles[$class_name]);
		$seed = new $class_name();
		
		$seed->retrieve($bean->id);
		$GLOBALS['log']->debug("APWF_WorkFlow completeDataBean class_name: " . $class_name);
		switch($bean->module_dir){
			case 'Cases': 
				$GLOBALS['log']->debug("APWF_WorkFlow completeDataBean seed->case_number: " . $seed->case_number);
				$bean->case_number = $seed->case_number;
			break;
		}
	}
	
}
?>
