<?php 
if(!defined('sugarEntry') || !sugarEntry) die('Not a Valid Entry Point');
global  $beanList, $beanFiles;
require_once('service/core/SoapHelperWebService.php');

$class_name = $beanList[$_GET['module_name']];
require_once($beanFiles[$class_name]);
$seed = new $class_name();

$helperObject = new SoapHelperWebServices();
$fields = $helperObject->get_return_module_fields($seed, $_GET['module_name'], '');
header('Content-type: application/json');
echo json_encode(array('results' => array_values($fields['module_fields'])));
