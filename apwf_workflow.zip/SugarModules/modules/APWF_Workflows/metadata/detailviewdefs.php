<?php
$module_name = 'APWF_Workflows';
$viewdefs [$module_name] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'syncDetailEditViews' => true,
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 'name',
          1 => 
          array (
            'name' => 'module_workflow',
            'label' => 'LBL_MODULE_WORKFLOW',
          ),
        ),
        1 => 
        array (
          0 => 'description',
          1 => 
          array (
            'name' => 'evento_workflow',
            'studio' => 'visible',
            'label' => 'LBL_EVENTO_WORKFLOW',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'status_workflow',
            'studio' => 'visible',
            'label' => 'LBL_STATUS_WORKFLOW',
          ),
          1 => 
          array (
            'name' => 'action_workflow',
            'studio' => 'visible',
            'label' => 'LBL_ACTION_WORKFLOW',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'email1',
          ),
          1 => 
          array (
            'name' => 'id_email_template',
						'label' => 'LBL_ID_EMAIL_TEMPLATE',
						'customCode' => '{$selectEmailTemplateField}',
          ),
        ),
        4 => 
        array (
          0 => 'assigned_user_name',
        ),
			),
			'lbl_editview_panel1' => 
			array(				
				0 => 
				array(
					0 => 
					array(
						'name' => 'line_detonadores_c',
						'customCode' => '{$lineDetonadores}',
					),
				),
			),
    ),
  ),
);
?>
