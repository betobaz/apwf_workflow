<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

require_once('include/MVC/View/views/view.edit.php');

class APWF_WorkflowsViewEdit extends ViewEdit {

	function APWF_WorkflowsViewEdit(){
		parent::ViewEdit();		
 	}
	
	function display(){
		$this->populateWorkflow();
		$this->populateDetonadores();
		$this->populateEmailAddresses();
		//echo print_r($this->bean, true);
		parent::display();
		$this->displayJS();
	}
	function populateWorkflow(){
		$modules = $this->getModules();
		$modulesDropDown = "";
		foreach($modules as $module){
			$modulesDropDown[$module] = '<option value="'.$module.'">'.$module.'</option>';
		}
		$modulesDropDown[$this->bean->module_workflow] = str_replace("option value", 'option selected="selected" value', $modulesDropDown[$this->bean->module_workflow]);
		$modulesDropDown = '<select name="module_workflow">'.implode("", $modulesDropDown).'</select>';
		//echo nl2br(print_r($modulesDropDown,true));
		$this->ss->assign('modulesWorkflowDropDown',$modulesDropDown);
		$this->populateEmailTemplate();
	}

	
	function populateDetonadores(){
		global $mod_strings, $app_strings;
		global  $beanList, $beanFiles;
		require_once('service/core/SoapHelperWebService.php');
		
		require_once('modules/APWF_Detonadores/APWF_Detonadores.php');
		require_once('service/core/SoapHelperWebService.php');
		$detonador = new APWF_Detonadores();
		$helperObject = new SoapHelperWebServices();
		$fields = $helperObject->get_return_module_fields($detonador, 'APWF_Detonadores', array('comparacion'));
		$optionsComparacionField =  array_values($fields['module_fields']['comparacion']['options']);
		$optionsComparacionFieldAux = array();
		//echo nl2br(print_r($optionsComparacionField, true));
		$optionsComparacionHtml = array();
		foreach($optionsComparacionField as $optionComparacion){
			$optionsComparacionFieldAux[$optionComparacion['name']] = $optionComparacion['value'];
			$optionsComparacionHtml[$optionComparacion['name']]= '<option value="' . $optionComparacion['name'] . '">' . $optionComparacion['value'] . '</option>';
		}
		$optionsComparacionField = $optionsComparacionFieldAux;
		//Realizar la consulta para obtener los detonadores existentes
		$detonadoresBD = "";
		$removeIcon = SugarThemeRegistry::current()->getImage('delete_inline','align="absmiddle" alt="'.$app_strings['LNK_REMOVE'].'" border="0"');


		//Obtencion de las opciones de campos
		if($this->bean->module_workflow){	
			$class_name = $beanList[$this->bean->module_workflow];
			require_once($beanFiles[$class_name]);
			$seed = new $class_name();

			$helperObject = new SoapHelperWebServices();
			$fields = $helperObject->get_return_module_fields($seed, $this->bean->module_workflow, '');			
			$moduleFields = $fields['module_fields'];

			//		echo print_r($moduleFields, true);
			$optionsModuleHtml = array();
			foreach($moduleFields as $field){
				$optionsModuleHtml[$field['name']] = <<<html
	<option value="{$field['name']}">{$field['label']}</option>
html;
			}
		}
		$detonadores = $this->bean->getDetonadores();
		$detonadoresRows = "";
		if(count($detonadores)){			
			//TODO obtener los campos del modulo
		 	$detonadoresRows	= $this->getHtmlDetonadoresRelated($detonadores, $optionsComparacionHtml, $optionsModuleHtml);
			
		}

		$optionsComparacionHtml = implode("", $optionsComparacionHtml);
		$optionsModuleHtml = $optionsModuleHtml ? implode("", $optionsModuleHtml) : "";
		$html = <<<html
	<section class="detonadores-content" >
<table class="grid">
	<thead>
		<tr>
			<th></th>
			<th>Campo:</th>
			<th>Comparaci&oacute;n:</th>
			<th>Valor:</th>
		</tr>
	</thead>
	<tbody>
<script type="text/javascript" class="template">
<tr>
<td><a href="#" class="remove">$removeIcon{$app_strings['LNK_REMOVE']}</a><input type="hidden" name="id_detonador[]"/></td>
<td><select name="field_trigger[]" class="field_trigger">$optionsModuleHtml</select></td>
<td><select name="comparacion[]">$optionsComparacionHtml</select></td>
<td><input type="text" name="value_trigger[]" /></td>
</tr>
</script>
	$detonadoresRows
	</tbody>
</table>
<button class="add-detonador">{$mod_strings['LBL_ADD_DETONADOR']}</button>
</section>

html;
		//echo $html;
		
		//Se obtiene los modulos disponibles
		
		$this->ss->assign('lineDetonadores',$html);
	}
	
	function displayJS(){
		global $app_strings, $mod_strings;
		
		echo '<script type="text/javascript">';
		$js=<<<JS
		
	$(function(){
		var o = $( {} ),
			cacheModules = {},
			moduleName = "",
			detonadoresDeleted = [],
			optionsModulesFields;

		$.each({
			trigger: 'publish',
			on: 'subscribe',
			off: 'unsubscribe'
		}, function( key, val ){
			jQuery[val] = function(){
				o[key].apply(o, arguments);
			}
		});
		var appDetonadores = $('.detonadores-content'),
				tbodyDetonadores = appDetonadores.find('tbody'),
				templateDetonador = $(appDetonadores.find('.template').html())
				;

		appDetonadores.find('.add-detonador').on('click', function(e){
			e.preventDefault();
			templateDetonador.find('select.field_trigger').html(optionsModulesFields);
			tbodyDetonadores.append(templateDetonador.clone());
		});

		appDetonadores.on('click', '.remove', function(e){
			var self = $(this)
			e.preventDefault();
			self.closest('tr').remove();
		});

		function getModulesFields(module_name){
			//console.log(module_name);
			moduleName = module_name
			$.getJSON('index.php?entryPoint=workflows_modules&module_name='+module_name, function(results){
				$.publish('workflows_modules/results', results);
			});
		}
		
		function fillModuleFields(fields){
			optionsModulesFields = "";
			$.map(fields, function(item, index){
				//console.log(item);
				optionsModulesFields += '<option value="' + item.name + '">' + item.label + '</option>';
			});
		}

		$('select[name=module_workflow]').on('change', function(){
			var self = $(this);
			tbodyDetonadores.find('tr').remove();
			if(cacheModules[self.val()] && cacheModules[self.val()].length){
				fillModuleFields(self.val());
			}
			else{
				cacheModules[self.val()] = null;
				getModulesFields($(this).val());
			}
			
		});
		
		$.subscribe('workflows_modules/results', function(e, results){
			//console.log(results);
			cacheModules[moduleName] =  results.results;
			//console.log(cacheModules);
			fillModuleFields(cacheModules[moduleName]);
		});

		var templateEmailAddress = $($('#template-email-address').html()),
			tbodyEmailAddresses = $('#content-email-addresses').find('tbody');
		
		$('.add-email-address').on('click', function(e){
			e.preventDefault();			
			tbodyEmailAddresses.append(templateEmailAddress.clone());
		});
		
		tbodyEmailAddresses.on('click', '.remove', function(e){
			e.preventDefault();
			$(this).closest('tr').remove();
		})
	});

	
	

JS;
		echo $js;				
		echo "</script>
			";
	}


	

	private function getModules(){
		$modules = array();
		$actions = ACLAction::getUserActions($user->id,true);
		foreach($actions as $key=>$value){
			if(isset($value['module']) && $value['module']['access']['aclaccess'] < ACL_ALLOW_ENABLED){
				if ($value['module']['access']['aclaccess'] == ACL_ALLOW_DISABLED) {
					unset($modules[$key]);
				} else {
					$modules[$key] = 'read_only';
				} // else
			} else {
				$modules[$key] = '';
			} // else
		} 
		return array_keys($modules);
	}

	private function getHtmlDetonadoresRelated($detonadores, $optionsComparacionHtml, $optionsModuleHtml){
		global $mod_strings, $app_strings;
		
		//echo print_r($optionsModuleHtml, true);		

		//echo print_r($moduleFields, true);
		
		$removeIcon = SugarThemeRegistry::current()->getImage('delete_inline','align="absmiddle" alt="'.$app_strings['LNK_REMOVE'].'" border="0"');

		foreach($detonadores as $detonador){
			$optionsComparacionHtmlAux = $optionsComparacionHtml;
			$optionsComparacionHtmlAux[$detonador->comparacion] = str_replace("option value", 'option selected="selected" value' , $optionsComparacionHtml[$detonador->comparacion]);
			$optionsComparacionDetonador = implode("",$optionsComparacionHtmlAux);
				
			$optionsModulesHtmlAux = $optionsModuleHtml;
			$optionsModulesHtmlAux[$detonador->field_trigger] = str_replace("option value", 'option selected="selected" value', $optionsModulesHtmlAux[$detonador->field_trigger]);
			$optionsModulesDetonador = implode("", $optionsModulesHtmlAux);
			$detonadoresRows .= <<<html
	<tr class="detonador">		
		<td><a href="#" class="remove">$removeIcon{$app_strings['LNK_REMOVE']}</a><input type="hidden" name="id_detonador[]"/></td>
		<td><select name="field_trigger[]" class="field_trigger">$optionsModulesDetonador</select></td>
		<td><select name="comparacion[]">$optionsComparacionDetonador</select></td>
		<td><input type="text" name="value_trigger[]" value="{$detonador->value_trigger}"/></td>
	</tr>
html;

		}

		return $detonadoresRows;
	}

	private function populateEmailAddresses(){
		global $mod_strings, $app_strings;
		
		$removeIcon = SugarThemeRegistry::current()->getImage('id-ff-remove','align="absmiddle" alt="'.$app_strings['LNK_REMOVE'].'" border="0"');

		$html = <<<html
	<section id="content-email-addresses" >
<table class="grid">
	<thead>
		<tr>
			<th></th>
			<th></th>
		</tr>
	</thead>
	<tbody>
<script type="text/javascript" id="template-email-address">
<tr>
<td><input type="text" size="30" name="email_address[]" /></td>
<td><a href="#" class="remove">$removeIcon</a></td>
</tr>
</script>
	$detonadoresRows
	</tbody>
</table>
<button class="add-email-address">{$mod_strings['LBL_ADD_EMAIL_ADDRESS']}</button>
</section>
html;
		$this->ss->assign('lineEmailAddresses',$html);
	}

	function populateEmailTemplate(){
		$email_templates_arr = get_bean_select_array(true, 'EmailTemplate','name','','name');
		//$emailTemplateOptions = get_select_options_with_id($email_templates_arr, "");
		$emailTemplatesOptions = array();
		foreach( $email_templates_arr as $key => $value ){
			$emailTemplatesOptions[$key] = '<option value="'.$key.'">'.$value.'</option>';
		}
		//echo print_r($this->bean->id_email_template, true);
		$emailTemplatesOptions[$this->bean->id_email_template] = str_replace("option value", 'option selected="selected" value', $emailTemplatesOptions[$this->bean->id_email_template]);
		$emailTemplatesOptions = implode("", $emailTemplatesOptions);
		//echo print_r($email_templates_arr, true);
		$html = <<<HTML
	<select  id="id_email_template" name='id_email_template' tabindex='2' >$emailTemplatesOptions</select>
HTML;
		$this->ss->assign('selectEmailTemplateField',$html);
		
	}		
}
?>
