<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

require_once('include/MVC/View/views/view.detail.php');

class APWF_WorkflowsViewDetail extends ViewDetail {
	var $currSymbol;
	function APWF_WorkflowsViewDetail(){
 		parent::ViewDetail();
 	}
	
	function display(){
		$this->populateWorkflow();	
		$this->populateDetonadores();
		$this->options['show_subpanels'] = false;
		parent::display();
	}

	private function populateWorkflow(){
		global  $beanList, $beanFiles;
		require_once($beanFiles['EmailTemplate']);
		$emailTemplate = new EmailTemplate();
		$emailTemplate->retrieve($this->bean->id_email_template);
		$this->ss->assign('selectEmailTemplateField',$emailTemplate->name);
	}

	private function populateDetonadores(){		
		global  $beanList, $beanFiles;
		require_once('modules/APWF_Detonadores/views/view.detail.php');
		require_once('service/core/SoapHelperWebService.php');
		$detonadorView = new APWF_DetonadoresViewDetail();

		$detonadores = $this->bean->getDetonadores();
		
		
		$detonadoresRows = "";
		if(count($detonadores)){
			$helperObject = new SoapHelperWebServices();
			$detonadorFields = $helperObject->get_return_module_fields($detonadores[0], 'APWF_Detonadores', array('comparacion'));
			$detonadorFields = $detonadorFields['module_fields'];


			$class_name = $beanList[$this->bean->module_workflow];
			require_once($beanFiles[$class_name]);
			$seed = new $class_name();

			$helperObject = new SoapHelperWebServices();
			$moduleFields = $helperObject->get_return_module_fields($seed, $this->bean->module_workflow, '');			
			$moduleFields = $moduleFields['module_fields'];
			
			foreach($detonadores as $detonador){
				$detonadoresRows = $detonadorView->getHtmlDetailRow($detonador, $detonadorFields, $moduleFields);
			}			
		}
		$html = <<<html
	<section class="detonadores-content" >
<table class="grid">
	<thead>
		<tr>
			<th>Campo:</th>
			<th>Comparaci&oacute;n:</th>
			<th>Valor:</th>
		</tr>
	</thead>
	<tbody>
	$detonadoresRows
	</tbody>
</table>
</section>

html;
		$this->ss->assign( 'lineDetonadores', $html );
	}
	


	
}
?>
