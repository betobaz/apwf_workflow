<?php
//require_once("modules/Leads/Lead.php");
require_once("modules/APWF_Workflows/APWF_Workflows.php");
class APWF_WorkflowHooks
{
	public function cargaPreDataWorkflow(SugarBean $bean, $event, $arguments){		
		$bean->wfPreData = $bean->fetched_row;
	}

	public function ejecutaWorkflow(SugarBean $bean, $event, $arguments){
		$eventWorkflow = "";
		if($event === 'after_save'){
			if($bean->wfPreData){
				$eventWorkflow = 'update';
			}else{
				$eventWorkflow = 'create';
			}
		}else if($event === 'after_delete'){
			$eventWorkflow = 'delete';
		}
		//$GLOBALS['log']->debug("executeWorkflow eventWorkflow: " . $eventWorkflow);
		if($eventWorkflow){
			$db = DBManagerFactory::getInstance();
			$resultFlows = $db->query("SELECT id FROM apwf_workflows aw WHERE aw.evento_workflow = '$eventWorkflow' AND aw.module_workflow = '$bean->module_dir' and aw.status_workflow = 'active'");			
			while($row = $db->fetchByAssoc($resultFlows)){
				$workflow = new APWF_WorkFlows();
				$workflow->retrieve($row['id']);
				if(!empty($workflow->id)){
					$GLOBALS['log']->debug("executeWorkflow ejecutaWorkflow bean->wfPreData: " . print_r($bean->wfPreData, true));
					$GLOBALS['log']->debug("executeWorkflow encuentra flujo: " . $workflow->id);
					$workflow->process($bean);
					//$detonadores = $workflow->getDetonadores();
					
					

				}

			}
		}
		
	}
	

	
}
